<?php

/*
 * All database connection variables
 */

define('DB_USER', "u753737966_desin"); // db user
define('DB_PASSWORD', "300dpi"); // db password (mention your db password here)
define('DB_DATABASE', "u753737966_carpe"); // database name
define('DB_HOST', "mysql.hostinger.in"); // db server
?>